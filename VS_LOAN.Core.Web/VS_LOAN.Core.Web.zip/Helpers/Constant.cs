﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VS_LOAN.Core.Web.Helpers
{
    public class Constant
    {
        public const string SESSION_LOGIN = "430A84AAD2AB44B6B4AEECCF5148A369";
        public const string SESSION_LIST_RULE = "430A84AAD2AB44B6B4AEECCF5148A370";
        public const string SESSION_CORE_LINK = "CORE_Link";
        public const string SESSION_LANGUAGE = "CORE_LANGUAGE";
        public const string SESSION_LINKBACK = "SESSION_LINKBACK";
        public const string SESSION_ACTIVELAG = "SESSION_ACTIVELAG";
        public const string FIRST_AD = "FIRST_AD";
        public const bool CHECK_AD = true;
        public const float BREAKFAST_PROPORTION = 0.2f;
        public const float LUNCH_PROPORTION = 0.3f;
        public const float DINNER_PROPORTION = 0.3f;
        public const float OTHER_PROPORTION = 0.2f;
    }
}