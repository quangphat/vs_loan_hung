namespace SCTV.Scrm.Web.Helpers.DataTables
{
    public class DataTableColumn
    {
        public int ColumnIndex { get; set; }
        public string SortDirection { get; set; }
        public string SearchTerm { get; set; }
    }
}