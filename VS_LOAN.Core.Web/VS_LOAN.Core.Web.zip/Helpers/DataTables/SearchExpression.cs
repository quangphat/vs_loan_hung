namespace SCTV.Scrm.Web.Helpers.DataTables
{
    public class SearchExpression
    {
        public ComparisonType Type { get; set; }
        public string Value { get; set; }
    }
}