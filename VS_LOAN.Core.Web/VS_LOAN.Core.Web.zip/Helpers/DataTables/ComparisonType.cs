namespace SCTV.Scrm.Web.Helpers.DataTables
{
    public enum ComparisonType
    {
        Default = 0,
        Equals,
        GreaterThan,
        GreaterThanOrEquals,
        LessThan,
        LessThanOrEquals,
        NotEquals,
        StartsWith,
        EndsWith
    }
}