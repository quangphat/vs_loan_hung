﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VS_LOAN.Core.Web.Helpers
{
    public class ActionInfo
    {
        public string _formindex;
        public int[] _mangChucNang;
        public string _href;
    }
}