﻿using System;

namespace VS_LOAN.Core.Web.Helpers
{
    internal class DataMemberAttribute : Attribute
    {
    }
}