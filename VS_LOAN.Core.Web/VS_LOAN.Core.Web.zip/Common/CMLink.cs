﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VS_LOAN.Core.Web.Common
{
   public class CMLink
    {
        public static string PathLogo = "http://portal.vietbankfc.vn/Content/images/FintechcomLogo.png";
    }
}
